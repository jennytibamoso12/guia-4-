/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parqueaderosolluna;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.field.types.DateType;
import com.j256.ormlite.table.DatabaseTable;
import java.util.Date;
import javax.annotation.Generated;

/**
 *
 * @author jamol
 */
@DatabaseTable
public class Parqueadero {
    
    @DatabaseField(generatedId =true)
    private long id;
    @DatabaseField
    private String propietario;
    @DatabaseField
    private String placa;
    @DatabaseField
    private String tipoVehiculo;
    @DatabaseField
    private Date fechaEntrada; 
    @DatabaseField (canBeNull = true)
    private String fechaSalida;
    @DatabaseField
    private float pagoTotal;

      
    
    public Parqueadero() {
    }

    public Parqueadero(String propietario, String placa, String tipoVehiculo) {
        this.propietario = propietario;
        this.placa = placa;
        this.tipoVehiculo = tipoVehiculo;
        this.fechaEntrada = new Date();
        this.fechaSalida = "-1";
        this.pagoTotal = 0;
    }

   
   
    @Override
    public String toString() {
        return "Parqueadero{" + "id=" + id + ", propietario=" + propietario + ", placa=" + placa + ", tipoVehiculo=" + tipoVehiculo + ", fechaEntrada=" + fechaEntrada + ", fechaSalida=" + fechaSalida + ", pagoTotal=" + pagoTotal + '}';
    }

        
    /**
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * @return the propietario
     */
    public String getPropietario() {
        return propietario;
    }

    /**
     * @param propietario the propietario to set
     */
    public void setPropietario(String propietario) {
        this.propietario = propietario;
    }

    /**
     * @return the placa
     */
    public String getPlaca() {
        return placa;
    }

    /**
     * @param placa the placa to set
     */
    public void setPlaca(String placa) {
        this.placa = placa;
    }

    /**
     * @return the tipoVehiculo
     */
    public String getTipoVehiculo() {
        return tipoVehiculo;
    }

    /**
     * @param tipoVehiculo the tipoVehiculo to set
     */
    public void setTipoVehiculo(String tipoVehiculo) {
        this.tipoVehiculo = tipoVehiculo;
    }

    /**
     * @return the fechaEntrada
     */
    public Date getFechaEntrada() {
        return fechaEntrada;
    }

    /**
     * @param fechaEntrada the fechaEntrada to set
     */
    public void setDate(Date fechaEntrada) {
        this.fechaEntrada = fechaEntrada;
    }

    /**
     * @return the fechaSalida
     */
    public String getFechaSalida() {
        return fechaSalida;
    }

    /**
     * @param fechaSalida the fechaSalida to set
     */
    public void setFechaSalida(String fechaSalida) {
        this.fechaSalida = fechaSalida;
    }

    /**
     * @return the pagoTotal
     */
    public float getPagoTotal() {
        return pagoTotal;
    }

    /**
     * @param pagoTotal the pagoTotal to set
     */
    public void setPagoTotal(float pagoTotal) {
        this.pagoTotal = pagoTotal;
    }

    
    
    
    
    
}