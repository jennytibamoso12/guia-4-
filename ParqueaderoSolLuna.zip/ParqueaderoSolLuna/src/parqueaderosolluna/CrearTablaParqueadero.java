/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parqueaderosolluna;

import com.j256.ormlite.jdbc.JdbcConnectionSource;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.table.TableUtils;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jamol
 */
public class CrearTablaParqueadero {
    public static void main(String[] args) throws SQLException {
        String nombreArchivo= "jdbc:h2:./Parqueadero";
        ConnectionSource conn = new JdbcConnectionSource(nombreArchivo);        
        TableUtils.createTable(conn, Parqueadero.class);
        //TableUtils.dropTable(conn, Parqueadero.class, true);
        System.out.println("La tabla fue creada exitosamente");
        try {
            conn.close();
        } catch (IOException ex) {
            Logger.getLogger(CrearTablaParqueadero.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
}
